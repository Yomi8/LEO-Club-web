-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: clabes_leo_club
-- ------------------------------------------------------
-- Server version 	8.0.34-0ubuntu0.20.04.1
-- Date: Wed, 30 Aug 2023 21:51:15 +0000

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `events`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Event` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Classification` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Occurance` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `events` VALUES (1,'Plunket Teddy Bears Picnic','work','support','yearly'),(2,'ANZAC poppies','prepare, sell, make donations to a cause','support','yearly'),(3,'Relay for Life','participate','activity','biyearly'),(4,'NZ Blood Collection','money collection','support','whenever'),(5,'Arthritis','money collection','support','whenever'),(6,'Alzheimer','money collection','support','whenever'),(7,'Child Cancer','money collection','support','whenever'),(8,'Epilepsy','money collection','support','whenever'),(9,'Diabetes','money collection','support','whenever'),(10,'Ronald McDonald','money collection','support','whenever'),(11,'Valentine’s Day balloons','prepare, sell, make donations to a cause','activity','yearly'),(12,'BBQs at school events','prepare, sell, make donations to a cause','activity','yearly'),(13,'Collect glasses/hearing aids for the Pacific Islands','collection','support','yearly'),(14,'Collect old and foreign currency through the LIONS CLUB - funds for Youth Development','collection','activity','yearly'),(15,'Hire a helper event at school to raise money for a selected charity','money collection','support','yearly'),(16,'The Ball Extravaganza','event, money collection','support','yearly'),(17,'LIONS Speechmaker competition','other','opportunity','yearly'),(18,'Borland Lodge Leadership Course April','enrichment','opportunity','school holidays'),(19,'Makarewa Tertiary Scholarship','enrichment','scholarship','yearly'),(20,'Attending LIONS meetings','enrichment','opportunity','whenever');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `events` with 20 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET AUTOCOMMIT=@OLD_AUTOCOMMIT */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Wed, 30 Aug 2023 21:51:15 +0000
