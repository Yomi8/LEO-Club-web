// === Accesability Panel === 
document.addEventListener('DOMContentLoaded', function () {
  const panelToggleBtn = document.getElementById('panelToggleBtn');
  const panel = document.querySelector('.panel');

  // Get the switches for contrast, font size, and font
  const contrastSwitch = document.getElementById('contrast');
  const fontSizeSwitch = document.getElementById('font-size');
  const fontSwitch = document.getElementById('font');

  let panelOpen = false;

  panelToggleBtn.addEventListener('click', () => {
    panelOpen = !panelOpen;
    if (panelOpen) {
      panel.style.width = '300px'; // Adjust the width as needed
    } else {
      panel.style.width = '0';
    }
  });

  // Function to toggle font size and font family
  function toggleFontSettings() {
    const textContent = document.querySelector('.text-content');
    if (fontSizeSwitch.checked) {
      textContent.p.style.fontSize = '20px'; // Adjust the font size as needed
    } else {
      textContent.p.style.fontSize = '16px'; // Default font size
    }
    if (fontSwitch.checked) {
      textContent.p.style.fontFamily = 'Arial, sans-serif'; // Adjust the font family as needed
    } else {
      textContent.p.style.fontFamily = 'Paragraph'; // Default font family
    }
  }

  // Function to toggle contrast and change footer background color
  function toggleContrast() {
    const footer = document.querySelector('.footer');
    if (contrastSwitch.checked) {
      footer.style.backgroundColor = '#68533B'; // Change footer background color
    } else {
      footer.style.backgroundColor = '#a37f5b'; // Default footer background color
    }
  }

  // Add event listeners for switches
  contrastSwitch.addEventListener('change', toggleContrast);
  fontSizeSwitch.addEventListener('change', toggleFontSettings);
  fontSwitch.addEventListener('change', toggleFontSettings);
});







