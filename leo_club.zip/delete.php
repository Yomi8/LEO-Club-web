<?php					
	require_once 'connect.php';
	
	$ID = $_REQUEST ['ID'];
	$sql = "DELETE FROM events WHERE ID = '" . $ID . "'";
	if (mysqli_query ($conn,$sql)) {
		print ("Deleted");
	}
	else {
		print ("Failed");
	}
	echo "<script>location.href='events.php'</script>"
?>