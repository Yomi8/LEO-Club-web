<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<link rel="icon" type="image/x-icon" href="images/Lions_Clubs_International_logo.svg.png">
	<title>Events - JHC LEO</title>
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/database.css" rel="stylesheet" type="text/css">
	<script src="script.js"></script>
</head>

<body class="container">
  <!-- Header -->
  <div class="header">
    <div class="logo-title">
      <img id="header_image" src="images/Hargest_logo.jpg">
      <h2 id="header_text">LEO Club</h2>
    </div>
    <div class="clear"></div>
  </div>
  

  <!-- Content -->
  <div class="nav-content-container">
    <!-- Navbar -->
    <div class="navbar">
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="contact.html">Contact</a></li>
		<li class="active"><a href="events.html">Events</a></li>
      </ul>
    </div>
    <!-- Main Content -->
    <div id="events-page-content">
		<!--PHP Connection Code -->
		<?php
			
			require_once 'connect.php';

			$sortColumn = isset($_GET['sort']) ? $_GET['sort'] : 'event';
			$sortDirection = isset($_GET['dir']) ? $_GET['dir'] : 'asc';

			$sql = "SELECT * FROM events ORDER BY $sortColumn $sortDirection";
			$result = $conn->query($sql);
		
			$newSortDirection = $sortDirection == 'asc' ? 'desc' : 'asc';
		?>
		
		<section id="event-table">
			<h2 class="heading">Events</h2>
			<table>
				<tr>
    				<th><a href="?sort=event&dir=<?php echo $newSortDirection; ?>">Event</a></th>
    				<th><a href="?sort=type&dir=<?php echo $newSortDirection; ?>">Type</a></th>
    				<th><a href="?sort=classification&dir=<?php echo $newSortDirection; ?>">Classification</a></th>
    				<th><a href="?sort=occurance&dir=<?php echo $newSortDirection; ?>">Occurance</a></th>
  				</tr>
				<!-- Fetch Data from books table in database -->
				<?php
					while($rows=$result->fetch_assoc())
					{
				?>
				<tr class="sortable-row">
					<td><?php echo $rows['Event'];?></td>
					<td><?php echo $rows['Type'];?></td>
					<td><?php echo $rows['Classification'];?></td>
					<td><?php echo $rows['Occurance'];?></td>
					<td>
						<?php
							echo "<a href='delete.php?ID=" . $rows['ID'] . "'><button class='bntDelete'>DELETE</button></a>";
						?>
					</td>
				</tr>
				<?php
					}
				?>
			</table>
		</section>
		
		<div class="submit">
			<h2>Add a New Event</h2>
			<form action="insert_form.php" method="post">
				<label for="event">Event:</label>
				<input type="text" name="event" required maxlength="255">
				
				<br>
				
				<label for="type">Type:</label>
				<input type="text" name="type" required maxlength="100">
				
				<br>
				
				<label for="classification">Classifiction:</label>
				<input type="text" name="classification" required maxlength="50">
				
				<br>
				
				<label for="occurance">Occurance:</label>
				<input type="text" name="occurance" required maxlength="50">
				
				<br>
				
				<input type="submit" value="Submit">
			</form>
		</div>
    </div>
  </div>
  <div class="footer">
    <p>Copyright 2023 - Cameron Labes - James Hargest College</p>
  </div>
  <button id="panelToggleBtn"><img src="images/accesability-button.png"></button>
  <div class="panel">
    <div class="panel-content">
      <!-- Add your content here -->
      <h2 class="heading">Accesabilty Settings</h2>
      <h3>Change Page Contrast</h3>
      <label id="contrast" class="switch">
        <input type="checkbox">
        <span class="slider round"></span>
      </label>
      <h3>Enlarge Font Size</h3>
      <label id="font-size" class="switch">
        <input type="checkbox">
        <span class="slider round"></span>
      </label>
      <h3>Apply Sans-serif Font</h3>
      <label id="font" class="switch">
        <input type="checkbox">
        <span class="slider round"></span>
      </label>
    </div>
  </div>
</body>

</html>
