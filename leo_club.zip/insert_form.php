<?php
	
	//LOADED CONFIRMATION
	print("<h2>Loaded</h2>");
		
	//DATABASE CONNECTION
	require_once ("connect.php");

	$Event = mysqli_real_escape_string($conn,$_REQUEST['event']);
	$Type = mysqli_real_escape_string($conn,$_REQUEST['type']);
	$Classification = $_REQUEST ['classification'];
	$Occurance = $_REQUEST ['occurance'];

	$sql = "INSERT INTO events (Event, Type, Classification, Occurance)
			VALUES ('$Event','$Type','$Classification','$Occurance')";
	if ($conn->query($sql) === TRUE){
		echo "New record created successfully";
		sleep(100);
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	echo "<script>location.href='events.php'</script>"
?>


